import lombok.Data;

@Data
public class CustomerSearchForm {
    private String name;
    private String sex;
    private String birthdayFrom;
    private String birthdayTo;
    private int page = 0;
}
