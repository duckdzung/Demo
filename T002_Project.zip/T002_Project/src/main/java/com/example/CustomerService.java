import com.querydsl.core.BooleanBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Page<Customer> searchCustomers(CustomerSearchForm form) {
        QCustomer customer = QCustomer.customer;
        BooleanBuilder builder = new BooleanBuilder();

        if (form.getName() != null && !form.getName().isEmpty()) {
            builder.and(customer.name.containsIgnoreCase(form.getName()));
        }
        if (form.getSex() != null && !form.getSex().isEmpty()) {
            builder.and(customer.sex.eq(form.getSex()));
        }
        if (form.getBirthdayFrom() != null && !form.getBirthdayFrom().isEmpty()) {
            builder.and(customer.birthday.goe(convertDateFormat(form.getBirthdayFrom())));
        }
        if (form.getBirthdayTo() != null && !form.getBirthdayTo().isEmpty()) {
            builder.and(customer.birthday.loe(convertDateFormat(form.getBirthdayTo())));
        }

        Pageable pageable = PageRequest.of(form.getPage(), 10);
        return customerRepository.findAll(builder, pageable);
    }

    private String convertDateFormat(String date) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        return LocalDate.parse(date, inputFormatter).format(outputFormatter);
    }
}
