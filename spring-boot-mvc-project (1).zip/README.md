# Spring Boot MVC Project (No Maven/Gradle)

## Cách chạy dự án

1. **Biên dịch mã nguồn:**  
   ```sh
   javac -cp "lib/*" -d out src/com/example/demo/**/*.java
   ```

2. **Chạy ứng dụng:**  
   ```sh
   java -cp "lib/*:out" -Dspring.devtools.restart.enabled=true com.example.demo.DemoApplication
   ```

3. **Mở trình duyệt và truy cập:**  
   ```
   http://localhost:8080/users
   ```

## Hot Reloading
- **Spring Boot DevTools** đã được bật (`lib/spring-boot-devtools.jar` cần tải về).  
- Mỗi khi bạn sửa code, ứng dụng sẽ tự động reload mà không cần restart.

## Cấu trúc thư mục
```
spring-boot-mvc/
│── lib/                     # Chứa thư viện JAR
│── src/com/example/demo/  
│   ├── DemoApplication.java  # File khởi động Spring Boot
│   ├── controller/
│   │   ├── UserController.java
│   ├── entity/
│   │   ├── User.java
│   ├── repository/
│   │   ├── UserRepository.java
│   ├── service/
│   │   ├── UserService.java
│── webapp/WEB-INF/views/     # Chứa JSP
│   ├── users.jsp
│   ├── add-user.jsp
│   ├── edit-user.jsp
│── resources/  
│   ├── application.properties # Cấu hình database
│── out/                       # Chứa file biên dịch
```

## 🐞 Debug ứng dụng Spring Boot

### **1️⃣ Chạy ứng dụng ở chế độ Debug**
Chạy ứng dụng với tham số debug:
```sh
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005 -cp "lib/*:out" com.example.demo.DemoApplication
```
- **Cổng 5005** sẽ mở để kết nối debugger.

### **2️⃣ Debug từ IDE (VS Code, IntelliJ, Eclipse)**
1. Mở **IDE** và tạo cấu hình Debug Remote:
   - **Host**: `localhost`
   - **Port**: `5005`
   - **Debugger Type**: `Attach to Remote JVM`
2. Đặt **Breakpoint** trong Controller, Service, Repository.
3. Kết nối Debugger và chạy thử.

### **3️⃣ Debug bằng `jdb` (Không cần IDE)**
Nếu không dùng IDE, có thể debug bằng `jdb`:
```sh
jdb -attach 5005
```
Các lệnh cơ bản:
- `stop at com.example.demo.controller.UserController.listUsers` → Đặt breakpoint
- `cont` → Tiếp tục chạy chương trình
- `print user` → Xem giá trị biến `user`

🔥 **Dùng IDE sẽ dễ debug hơn, nhưng nếu không có IDE, có thể dùng `jdb`.**
